import os
from flask import Flask, request, render_template, jsonify

app = Flask(__name__)

UPLOAD_FOLDER = "uploads"
FLAG = "HAUNT{simpl3_f1l3_uplo4d}"

# Create the upload folder if it doesn't exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return jsonify({"error": "No file selected"}), 400
    
    file = request.files["file"]

    if file.filename == "":
        return jsonify({"error": "No selected file"}), 400

    if file.filename != "flag.txt":
        return jsonify({"message": "File uploaded! But nothing special happened."})
    
    return jsonify({"flag": FLAG})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
