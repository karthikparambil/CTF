from flask import Flask, request, render_template, redirect, url_for

app = Flask(__name__)

users = {
    'jackskellington': {'id': 1, 'password': 'pumpkinking'},
    'sally': {'id': 2, 'password': 'ragdoll'},
    'zerox': {'id': 3, 'password': 'santa'}
}

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = users.get(username)
        if user and user['password'] == password:
            return redirect(url_for('dashboard', id=user['id']))
        else:
            return "Wrong incantation, mortal!", 403

    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    user_id = request.args.get('id')
    try:
        with open(f'data/{user_id}.txt') as f:
            content = f.read()
        return render_template('dashboard.html', content=content)
    except:
        return "No spooky notes found in this crypt."
    
from flask import render_template

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/about/dark')
def dark_about():
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Halloween Town Crypt</title>

        <!-- Halloween fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Creepster&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Nosifer&display=swap" rel="stylesheet">

        <style>
            body {
                background: url('https://wallpaperaccess.com/full/124582.jpg') no-repeat center center fixed;
                background-size: cover;
                color: #f5f5dc;
                font-family: 'Nosifer', serif;
                margin: 0; padding: 0;
                text-align: center;
                font-size: 20px; font-weight: bold;
                text-shadow: 2px 2px 4px #000;
            }
            h1 {
                font-size: 4em; margin-top: 40px;
                font-family: 'Creepster', cursive;
                text-shadow: 3px 3px 10px #8B0000;
                color: #FF4500;
            }
            .container {
                background: rgba(0, 0, 0, 0.85);
                padding: 60px;
                margin: 100px auto;
                width: 80%;
                border-radius: 20px;
                box-shadow: 0 0 30px #8B0000;
                border: 3px solid #FF4500;
            }
            p {
                font-size: 1.5em; line-height: 1.6;
                color: #f5f5dc;
                text-shadow: 1px 1px 3px #000;
                margin: 20px 0;
            }
            .password {
                font-size: 1.8em;
                color: #FF4500;
                font-family: 'Creepster', cursive;
                text-shadow: 2px 2px 6px #8B0000;
                margin-top: 30px;
            }
            a {
                color: #FF4500; text-decoration: none; font-weight: bold;
                text-shadow: 1px 1px 4px #000;
            }
            a:hover {
                color: #8B0000; text-shadow: 2px 2px 6px #000;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🎃 Halloween Town Crypt</h1>
            <p>Only those who can decipher the ancient spells may unlock the secrets of the night...</p>

            <!-- Visible Base64‑encoded password -->
            <p class="password">🔑 Spell: <strong>cHVtcGtpbmtpbmc=</strong></p>

            <p>Unravel the mystery, if you dare!</p>
            <p><a href="/">🦇 Return to the graveyard</a></p>
        </div>
    </body>
    </html>
    """



if __name__ == '__main__':
    app.run(debug=True)
