from flask import Flask, render_template, request, session, jsonify
import os

app = Flask(__name__)
app.secret_key = 'skulllock_secret_key_2024'

@app.route('/')
def index():
    """Main CTF challenge page"""
    response = render_template('index.html')
    response = app.make_response(response)
    response.headers['X-Secret-Flag'] = 'FLAG{sp00ky_hall0w33n_ctf}'
    return response

@app.route('/validate_flag', methods=['POST'])
def validate_flag():
    """Validate the submitted flag"""
    submitted_flag = request.form.get('flag', '')

    if submitted_flag == 'FLAG{sp00ky_hall0w33n_ctf}':
        return {'success': True, 'message': '🕯️ The crypt doors creak open... a dimly lit passage leads toward the skulllock sanctum 🗝️'}
    else:
        return {'success': False, 'message': 'Incorrect flag. Try again!'}

@app.route('/skulllock/')
def skulllock():
    """Protected admin panel that requires specific referrer"""
    message1 = ""
    message2 = ""
    flag = ""

    referer = request.headers.get('Referer')

    if referer and referer == 'http://localhost:3303/admin':
        flag = "HAUNT{midnight_walk}"
    else:
        message1 = "Access Denied!"
        message2 = "Only allow authorized users from admin page"

    return render_template('skulllock.html', flag=flag, message1=message1, message2=message2)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
