from flask import Flask, request, render_template, redirect, session
import sqlite3

app = Flask(__name__)
app.secret_key = "cursedsecret"

def get_db():
    conn = sqlite3.connect("database.db")
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    return render_template("login.html")

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    db = get_db()
    query = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
    try:
        user = db.execute(query).fetchone()
    except:
        user = None

    if user:
        session['user'] = username
        return redirect('/admin')
    else:
        return "No luck, landlubber!"

@app.route('/admin')
def admin():
    if 'user' in session:
        return render_template('fake_admin.html')
    return redirect('/')

@app.route('/blind')
def real_admin():
    ua = request.headers.get('User-Agent')
    if ua == "GhostMaster":
        return render_template('real_admin.html')
    return render_template("blind.html")

if __name__ == '__main__':
    app.run(debug=True,host="0.0.0.0")
